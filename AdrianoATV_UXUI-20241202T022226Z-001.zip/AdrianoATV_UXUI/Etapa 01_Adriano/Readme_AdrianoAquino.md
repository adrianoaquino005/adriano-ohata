## 1 Identificação de Risco Potencial: Injeção de SQL:


Análise: No método 'verificarUsuario', os parâmetros 'login' e 'senha' são diretamente concatenados na instrução SQL.
Risco: Usuários mal-intencionados podem injetar código SQL malicioso, comprometendo a segurança do banco de dados.

## 2 Deficiência no Tratamento de Exceções:

Análise: Blocos 'catch' estão sem implementação, silenciando as exceções durante a execução.
Risco: Dificulta a detecção e correção de erros durante a execução do programa.

## 3 Gestão Ineficiente de Recursos:

Análise: Recursos como 'Connection', 'Statement' e 'ResultSet' não estão sendo liberados após o uso.
Risco: Pode causar vazamento de recursos, levando a exceções e mau desempenho.

## 4 Exposição de Dados Sensíveis:

Análise: Credenciais estão codificadas diretamente no código-fonte, representando um risco de segurança.

## 5 Prática Obsoleta de Registro de Driver:

Análise: A prática manual de registro de drivers não é necessária a partir do JDBC 4.0.

## 6 Risco de Erro NullPointerException:

Problema: Se a conexão conn não for estabelecida, conn.createStatement() resultará em erro.

##  7 Ausência de Princípios de Responsabilidade Única:

Problema: A classe User está responsável por conexão com o banco e lógica de negócio.

## 8 Emprego de Variáveis de Escopo Global:

Problema: O uso de variáveis globais como nome pode levar a resultados inesperados em aplicações com múltiplos usuários.

## 9 Ausência de Validação de Conexão ao Banco de Dados:

Problema: Não há verificação se a conexão com o banco foi bem-sucedida antes de executar a consulta.





