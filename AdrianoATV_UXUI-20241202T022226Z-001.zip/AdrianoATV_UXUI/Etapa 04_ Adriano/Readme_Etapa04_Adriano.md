# Projeto de Avaliação Final - Etapa 04

Este projeto Java foi desenvolvido para implementar uma documentação detalhada e realizar testes de caixa branca com base em diagramas.

## Descrição

O projeto consiste em duas classes principais:

- `User.java`: Contém métodos para estabelecer conexão com o banco de dados e verificar se um usuário existe.
- `Teste.java`: Classe de teste para verificar o funcionamento dos métodos da classe `User`.

## Como Executar

Você precisará criar um banco de dados SQL utilizando os comandos abaixo:

Criação do Banco de dados
~~~SQL
CREATE DATABASE teste;
~~~
Criação da tabela usuarios
~~~SQL
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(50) NOT NULL,
    senha VARCHAR(50) NOT NULL,
    nome VARCHAR(100) NOT NULL
);
~~~

Inserir dados no seu banco de dados
~~~SQL
INSERT INTO usuarios (login, senha, nome) VALUES ('Zhefiroth', '1234', 'Matheus');
~~~
Certifique-se de configurar corretamente a URL de conexão conforme abaixo:

"jdbc:mysql://127.0.0.1/Nome_do_seu_Banco_de_Dados?user=Seu_usuario_do_MYSQL&password=Sua_senha"

Faça o download do arquivo JAR necessário no site oficial:

Colocar na opção Platform Independent e fazer Download do "Platform Independent (Architecture Independent), ZIP Archive"

e pegar o Jar mysql-connector-j-9.1.0 e adicionar ao seu projeto

Seguindo essas etapas, seu projeto estará configurado e funcional.



## Documentado por

Adriano Aquino


